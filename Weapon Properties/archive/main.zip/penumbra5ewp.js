Hooks.on('ready', () => {
	CONFIG.DND5E.weaponProperties['accurate'] = 'Accurate';
	CONFIG.DND5E.weaponProperties['attachment'] = 'Attachment';
  	CONFIG.DND5E.weaponProperties['bladed'] = 'Bladed';
	CONFIG.DND5E.weaponProperties['broad'] = 'Broad';
	CONFIG.DND5E.weaponProperties['burst'] = 'Burst';
	CONFIG.DND5E.weaponProperties['cartridge'] = 'Cartridge';
	CONFIG.DND5E.weaponProperties['composite'] = 'Composite';
	CONFIG.DND5E.weaponProperties['crushing'] = 'Crushing';
	CONFIG.DND5E.weaponProperties['doublebarreled'] = 'Double-barreled';
	CONFIG.DND5E.weaponProperties['doublebladed'] = 'Double-bladed';
	CONFIG.DND5E.weaponProperties['degraded1'] = 'Degraded: −1';
	CONFIG.DND5E.weaponProperties['degraded2'] = 'Degraded: −2';
	CONFIG.DND5E.weaponProperties['degraded3'] = 'Degraded: −3';
	CONFIG.DND5E.weaponProperties['degraded4'] = 'Degraded: −4';
	CONFIG.DND5E.weaponProperties['degraded5'] = 'Degraded: −5';
	CONFIG.DND5E.weaponProperties['hip'] = 'Hip';
	CONFIG.DND5E.weaponProperties['lacerating'] = 'Lacerating';
	CONFIG.DND5E.weaponProperties['magazine'] = 'Magazine';
	CONFIG.DND5E.weaponProperties['parrying'] = 'Parrying';
	CONFIG.DND5E.weaponProperties['pummeling'] = 'Pummeling';
	CONFIG.DND5E.weaponProperties['puncturing'] = 'Puncturing';
	CONFIG.DND5E.weaponProperties['sizet'] = 'Size: Tiny';
	CONFIG.DND5E.weaponProperties['sizem'] = 'Size: Medium';
	CONFIG.DND5E.weaponProperties['sizel'] = 'Size: Large';
	CONFIG.DND5E.weaponProperties['sizeh'] = 'Size: Huge';
	CONFIG.DND5E.weaponProperties['sizeg'] = 'Size: Gargantuan';
	CONFIG.DND5E.weaponProperties['sweep'] = 'Sweep';
	CONFIG.DND5E.weaponProperties['tampered'] = 'Tempered';
	CONFIG.DND5E.weaponProperties['thrust'] = 'Thrust';
	CONFIG.DND5E.weaponProperties['waterproof'] = 'Waterproof';

	
});

