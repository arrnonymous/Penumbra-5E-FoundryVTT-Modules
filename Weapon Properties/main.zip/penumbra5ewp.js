Hooks.on('ready', () => {
	CONFIG.DND5E.weaponProperties['attachment'] = 'Attachment';
  	CONFIG.DND5E.weaponProperties['bladed'] = 'Bladed';
	CONFIG.DND5E.weaponProperties['broad'] = 'Broad';
	CONFIG.DND5E.weaponProperties['burst'] = 'Burst';
	CONFIG.DND5E.weaponProperties['doublebladed'] = 'Double-bladed';
	CONFIG.DND5E.weaponProperties['hip'] = 'Hip';
	CONFIG.DND5E.weaponProperties['parrying'] = 'Parrying';
	CONFIG.DND5E.weaponProperties['puncturing'] = 'Puncturing';
	CONFIG.DND5E.weaponProperties['size'] = 'Size';
	CONFIG.DND5E.weaponProperties['sweep'] = 'Sweep';
	CONFIG.DND5E.weaponProperties['thrust'] = 'Thrust';

	
});

